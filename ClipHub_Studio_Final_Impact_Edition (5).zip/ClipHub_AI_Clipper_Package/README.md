# ClipHub Studio — Final Impact Edition

A local-first creator workspace with a high-contrast black/red/white visual system, animated impact frames on mouse clicks and touch taps, AI creator tools, image generation, a browser preview editor, and a server-side AI video clipper with authorized YouTube-link import.

## Start on Windows

1. Extract this folder to a location you can write to.
2. Double-click `run_windows.bat`.
3. The launcher creates a Python virtual environment and installs the packages in `requirements.txt` (first run needs internet).
4. Paste your Google AI Studio API key into the terminal prompt. Never share it or commit it to source control.
5. Keep the terminal window open while using ClipHub.
6. Open `http://127.0.0.1:8000`.
7. Check `http://127.0.0.1:8000/api/health` for safe diagnostics (the key itself is never returned).

## What's in this edition

- **22 AI creator tools**: ideas, scripts, titles, transcript clip finder, thumbnail concepts, trends brainstorm, image creator, hooks, voiceover, storyboard, scene commentary, top list, split screen, captions, repurposing, content calendar, profile/bio, descriptions, comment replies, A/B title test, script doctor and series planner.
- **ClipHub AI chat** through the server-side Gemini backend.
- **Image Creator** using Gemini image-generation models and configured fallback models.
- **AI Video Clipper**: upload local video or paste an authorized YouTube URL, ask Gemini to find highlight timestamps, and use FFmpeg to render downloadable MP4 clips. YouTube imports can fail if the source is restricted, unavailable, or YouTube changes its delivery formats.
- **Video Studio preview**: local video preview, trim-range selection, aspect ratio, filters, speed and caption overlay. Browser preview export is WebM and records in real time; use AI Clipper's backend export for MP4 clips.
- **Impact design**: black, red and white palette, bolder editorial typography, responsive cards, and a short burst of concentric rings with big/small/micro dots on pointer and touch interaction. Reduced-motion settings are respected.

## Configuration

The launcher currently configures Google Gemini for text, image and video analysis. Default model settings are in `run_windows.bat` and can also be configured with environment variables in deployments. Do not place real API keys in HTML, JavaScript, `.env.example`, or public repositories.

The `.env.example` file contains placeholders only. It is not loaded automatically by the Windows launcher. For hosted deployment, set the needed environment variables in your hosting provider's secret/environment settings.

## Important limitations and launch checklist

- **Not yet a production multi-user service.** This package runs locally by default. Public hosting requires a deployed backend, authentication or access controls as appropriate, per-user quotas/rate limits, upload cleanup, storage policies, and abuse protection.
- AI model availability, quotas and billing depend on Google AI Studio/project limits. Fallback models help with some transient errors but cannot guarantee uninterrupted service.
- YouTube downloading is only for content you own or are otherwise authorized to process, and subject to YouTube's terms and applicable rights. Private, age-restricted, region-blocked or otherwise restricted sources may not import.
- Uploaded videos are processed by the backend and may be sent to the configured AI provider for analysis. Do not upload confidential or sensitive footage unless you understand the provider's data terms.
- Check dependencies and run tests before publishing. The package was syntax-checked locally, but live AI provider requests and every third-party video URL cannot be guaranteed from this build environment.

## Troubleshooting

- If port 8000 is occupied, close the other ClipHub terminal window first.
- If the server fails to start, read the terminal error. Re-run the launcher after checking internet connectivity and Python installation.
- If Gemini reports overload/quota, wait, inspect Google AI Studio quota, or configure a model that is available to your project.
- If YouTube import fails with “Requested format is not available”, update `yt-dlp` (the launcher attempts this), ensure Deno 2.3+ or a compatible JavaScript runtime is installed, and try a different authorized public video. Some URLs may remain unavailable.
- The API key is never displayed by `/api/health`; still, keep the terminal private because you type the key into it at launch.
