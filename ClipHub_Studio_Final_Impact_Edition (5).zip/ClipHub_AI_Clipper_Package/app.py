from fastapi import FastAPI, HTTPException, UploadFile, File, Form
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from pathlib import Path
import os
import json
import httpx
import re
import subprocess
import tempfile
import time
import uuid
import shutil
from html import escape
from urllib.parse import urlparse, parse_qs

ROOT = Path(__file__).parent
app = FastAPI(title="ClipHub Studio API", version="1.2.0")
app.mount("/static", StaticFiles(directory=ROOT / "static"), name="static")

DEFAULT_MODEL = "gemini-3.5-flash-lite"
# If the primary model reports temporary overload / server errors, try these lighter
# generally available text models in order. Override with AI_FALLBACK_MODELS if desired.
DEFAULT_FALLBACK_MODELS = ["gemini-3.1-flash-lite", "gemini-3.6-flash"]
GEMINI_API_ROOT = "https://generativelanguage.googleapis.com/v1beta/models"
GEMINI_INTERACTIONS_URL = "https://generativelanguage.googleapis.com/v1beta/interactions"
DEFAULT_IMAGE_MODEL = "gemini-nano-banana-2.1"
DEFAULT_IMAGE_FALLBACK_MODELS = [
    "gemini-3.1-flash-image",
    "gemini-3.1-flash-lite-image",
    "gemini-2.5-flash-image",
]


def _configured_models() -> list[str]:
    primary = os.getenv("AI_MODEL", DEFAULT_MODEL).strip() or DEFAULT_MODEL
    fallbacks_raw = os.getenv("AI_FALLBACK_MODELS", ",".join(DEFAULT_FALLBACK_MODELS))
    fallbacks = [item.strip() for item in fallbacks_raw.split(",") if item.strip()]
    # Preserve order while avoiding duplicate model attempts.
    return list(dict.fromkeys([primary] + fallbacks))

def _configured_image_models() -> list[str]:
    primary = os.getenv("AI_IMAGE_MODEL", DEFAULT_IMAGE_MODEL).strip() or DEFAULT_IMAGE_MODEL
    fallbacks_raw = os.getenv("AI_IMAGE_FALLBACK_MODELS", ",".join(DEFAULT_IMAGE_FALLBACK_MODELS))
    fallbacks = [item.strip() for item in fallbacks_raw.split(",") if item.strip()]
    return list(dict.fromkeys([primary] + fallbacks))

class GenerateRequest(BaseModel):
    prompt: str

class ChatRequest(BaseModel):
    messages: list[dict]

class ImageRequest(BaseModel):
    prompt: str = Field(min_length=1, max_length=12000)
    aspect_ratio: str = "1:1"

@app.get("/")
def home():
    return FileResponse(ROOT / "static" / "index.html")

@app.get("/api/health")
def health():
    """Safe diagnostics: never returns the API key."""
    models = _configured_models()
    image_models = _configured_image_models()
    return {
        "status": "ok",
        "provider": "Google Gemini",
        "api_key_configured": bool(os.getenv("AI_API_KEY", "").strip()),
        "model": models[0],
        "fallback_models": models[1:],
        "image_model": image_models[0],
        "image_fallback_models": image_models[1:],
        "video_model": os.getenv("AI_VIDEO_MODEL", models[0]).strip() or models[0],
        "video_fallback_models": [item.strip() for item in os.getenv("AI_VIDEO_FALLBACK_MODELS", ",".join(models[1:])).split(",") if item.strip()],
        "clipper_enabled": True,
        "youtube_link_import_enabled": True,
        "max_video_upload_mb": int(os.getenv("CLIPHUB_MAX_CLIP_UPLOAD_MB", "250")),
        "note": "Chat, image generation and video clipping run through the ClipHub backend. Gemini analyzes video; FFmpeg renders clips. API usage and upload limits apply.",
    }

def _provider_error_message(status_code: int, response_text: str, api_key: str) -> str:
    """Convert Google's error response into a useful message without exposing secrets."""
    raw_message = ""
    try:
        payload = json.loads(response_text)
        err = payload.get("error", {}) if isinstance(payload, dict) else {}
        raw_message = str(err.get("message", ""))
        status = str(err.get("status", ""))
    except Exception:
        status = ""
        raw_message = ""

    # Never echo the configured secret, even if a provider response unexpectedly contains it.
    if api_key:
        raw_message = raw_message.replace(api_key, "[hidden API key]")
    raw_message = " ".join(raw_message.split())[:350]
    lower = (raw_message + " " + status).lower()

    if status_code in (401, 403) or "api key not valid" in lower or "invalid_api_key" in lower:
        base = "Google rejected the API key. Create/copy a valid key from Google AI Studio and make sure the Gemini API is available for its project."
    elif status_code == 429 or "quota" in lower or "resource_exhausted" in lower or "rate limit" in lower:
        base = "Google Gemini quota or rate limit reached. Check AI Studio billing/quota and wait if you hit a temporary rate limit."
    elif status_code == 404 or "not found" in lower or "unknown model" in lower:
        base = "Google could not find this model for the API request. Check the model name in the launcher or use a model available to your AI Studio key."
    elif status_code == 400:
        base = "Google rejected the request format or model settings."
    elif status_code >= 500:
        base = "Google Gemini is temporarily having a server-side problem. Try again later."
    else:
        base = f"Google Gemini returned HTTP {status_code}."

    if raw_message:
        return f"{base} Google details: {raw_message}"
    return base

async def call_model(messages: list[dict]) -> dict[str, str]:
    api_key = os.getenv("AI_API_KEY", "").strip()
    models = _configured_models()

    if not api_key:
        raise HTTPException(
            status_code=503,
            detail="Google AI Studio API key is not configured. Close ClipHub and run run_windows.bat again, then paste your key when asked."
        )

    system_parts = []
    contents = []
    for message in messages:
        role = message.get("role", "user")
        content = str(message.get("content", ""))[:12000]
        if not content:
            continue
        if role == "system":
            system_parts.append(content)
        elif role == "assistant":
            contents.append({"role": "model", "parts": [{"text": content}]})
        elif role == "user":
            contents.append({"role": "user", "parts": [{"text": content}]})

    if not contents:
        raise HTTPException(status_code=400, detail="Enter a message before sending it to ClipHub AI.")

    body = {"contents": contents, "generationConfig": {"temperature": 0.7, "maxOutputTokens": 2048}}
    if system_parts:
        body["systemInstruction"] = {"parts": [{"text": "\n\n".join(system_parts)}]}

    headers = {"Content-Type": "application/json", "x-goog-api-key": api_key}
    last_error = None
    attempted_models = []

    try:
        async with httpx.AsyncClient(timeout=90) as client:
            for index, model in enumerate(models):
                attempted_models.append(model)
                endpoint = f"{GEMINI_API_ROOT}/{model}:generateContent"
                response = await client.post(endpoint, headers=headers, json=body)
                if response.is_error:
                    detail = _provider_error_message(response.status_code, response.text, api_key)
                    last_error = (response.status_code, detail)
                    # Retry another model only for transient overload/server errors or
                    # a model-specific rate limit. Don't mask invalid keys or bad requests.
                    if response.status_code == 429 or response.status_code in (500, 502, 503, 504):
                        if index + 1 < len(models):
                            continue
                    raise HTTPException(status_code=502, detail=detail)

                data = response.json()
                candidates = data.get("candidates", [])
                if not candidates:
                    feedback = data.get("promptFeedback", {})
                    reason = str(feedback.get("blockReason", ""))
                    if reason:
                        raise HTTPException(status_code=502, detail=f"Google Gemini did not return a response. Safety block reason: {reason}.")
                    raise HTTPException(status_code=502, detail="Google Gemini returned no answer. Try a shorter message.")
                parts = candidates[0].get("content", {}).get("parts", [])
                answer = "\n".join(str(part.get("text", "")) for part in parts if part.get("text"))
                if not answer.strip():
                    raise HTTPException(status_code=502, detail="Google Gemini returned an empty answer. Try again.")
                return {"text": answer.strip(), "model": model, "fallback_used": model != models[0]}

        if last_error:
            status_code, detail = last_error
            models_text = ", ".join(attempted_models)
            raise HTTPException(status_code=502, detail=f"ClipHub tried these Gemini models: {models_text}. They are all currently busy or rate-limited. Google’s last message: {detail}")
        raise HTTPException(status_code=502, detail="No Gemini model returned a response. Please try again.")
    except HTTPException:
        raise
    except httpx.TimeoutException as exc:
        raise HTTPException(status_code=504, detail="The request to Google Gemini timed out. Check your internet connection and try again.") from exc
    except httpx.ConnectError as exc:
        raise HTTPException(status_code=502, detail="ClipHub could not connect to Google Gemini. Check your internet connection, VPN, firewall, or proxy settings.") from exc
    except (ValueError, KeyError, TypeError) as exc:
        raise HTTPException(status_code=502, detail="ClipHub received an unexpected response from Google Gemini. Check the server window for details.") from exc
    except httpx.HTTPError as exc:
        raise HTTPException(status_code=502, detail=f"Network error while contacting Google Gemini ({type(exc).__name__}). Check your connection and try again.") from exc

@app.post("/api/generate")
async def generate(req: GenerateRequest):
    prompt = req.prompt.strip()
    if not prompt or len(prompt) > 20000:
        raise HTTPException(status_code=400, detail="Prompt must be between 1 and 20,000 characters.")
    result = await call_model([
        {"role": "system", "content": "You are ClipHub AI, a helpful short-form video creator assistant. Be clear, creative, and honest."},
        {"role": "user", "content": prompt},
    ])
    return result

@app.post("/api/image")
async def generate_image(req: ImageRequest):
    """Generate a real PNG with Gemini's image-generation models, rather than asking a text model to write SVG code."""
    api_key = os.getenv("AI_API_KEY", "").strip()
    if not api_key:
        raise HTTPException(status_code=503, detail="Google AI Studio API key is not configured. Close ClipHub and run run_windows.bat again, then paste your key when asked.")

    allowed_ratios = {"1:1", "3:2", "2:3", "16:9", "9:16", "4:3", "3:4", "5:4", "4:5"}
    aspect_ratio = req.aspect_ratio if req.aspect_ratio in allowed_ratios else "1:1"
    prompt = "Create an original, polished image based on this brief. Produce an image, not SVG, HTML, code, or a written explanation. Make the composition clear and visually appealing. Brief: " + req.prompt.strip()
    models = _configured_image_models()
    headers = {"Content-Type": "application/json", "x-goog-api-key": api_key}
    last_error = None
    attempted_models = []

    try:
        async with httpx.AsyncClient(timeout=180) as client:
            for index, model in enumerate(models):
                attempted_models.append(model)
                body = {
                    "model": model,
                    "input": prompt,
                    "store": False,
                    "response_format": {
                        "type": "image",
                        "mime_type": "image/png",
                        "aspect_ratio": aspect_ratio,
                        "image_size": "1K",
                    },
                }
                response = await client.post(GEMINI_INTERACTIONS_URL, headers=headers, json=body)
                if response.is_error:
                    detail = _provider_error_message(response.status_code, response.text, api_key)
                    last_error = (response.status_code, detail)
                    # Try image-specific backup models for overloads, rate limits, or models
                    # unavailable to the current key. Do not retry invalid keys or bad prompts.
                    if response.status_code in (404, 429, 500, 502, 503, 504) and index + 1 < len(models):
                        continue
                    raise HTTPException(status_code=502, detail=detail)

                payload = response.json()
                image_block = payload.get("output_image") if isinstance(payload, dict) else None
                if not isinstance(image_block, dict):
                    image_block = None
                    # Tolerate the generic REST output representation as well as the SDK convenience field.
                    outputs = payload.get("output", []) if isinstance(payload, dict) else []
                    if isinstance(outputs, list):
                        for block in outputs:
                            if isinstance(block, dict) and block.get("type") in ("image", "output_image") and block.get("data"):
                                image_block = block
                                break
                    if image_block is None:
                        # The raw REST API usually returns generated media inside
                        # steps[].content[], while the official SDK exposes output_image
                        # as a convenience property.
                        steps = payload.get("steps", []) if isinstance(payload, dict) else []
                        if isinstance(steps, list):
                            for step in reversed(steps):
                                if not isinstance(step, dict):
                                    continue
                                content_blocks = step.get("content", [])
                                if isinstance(content_blocks, list):
                                    for block in reversed(content_blocks):
                                        if isinstance(block, dict) and block.get("type") in ("image", "output_image") and block.get("data"):
                                            image_block = block
                                            break
                                if image_block is not None:
                                    break
                                candidate = step.get("output_image") or step.get("image")
                                if isinstance(candidate, dict) and candidate.get("data"):
                                    image_block = candidate
                                    break
                image_data = image_block.get("data") if isinstance(image_block, dict) else None
                mime_type = image_block.get("mime_type", "image/png") if isinstance(image_block, dict) else "image/png"
                if not image_data:
                    text_output = ""
                    if isinstance(payload, dict):
                        text_output = str(payload.get("output_text", "") or "").strip()
                    extra = f" Google response: {text_output[:240]}" if text_output else ""
                    raise HTTPException(status_code=502, detail="Google returned a response but no image data. Check that image generation is available for your Gemini API project." + extra)
                if mime_type not in ("image/png", "image/jpeg", "image/webp"):
                    mime_type = "image/png"
                return {
                    "data_url": f"data:{mime_type};base64,{image_data}",
                    "mime_type": mime_type,
                    "model": model,
                    "fallback_used": model != models[0],
                }

        if last_error:
            _, detail = last_error
            raise HTTPException(status_code=502, detail=f"ClipHub tried these image models: {', '.join(attempted_models)}. None returned an image. Google’s last message: {detail}")
        raise HTTPException(status_code=502, detail="No Gemini image model returned an image. Please try again.")
    except HTTPException:
        raise
    except httpx.TimeoutException as exc:
        raise HTTPException(status_code=504, detail="Gemini image generation timed out. Try a shorter prompt or try again later.") from exc
    except httpx.ConnectError as exc:
        raise HTTPException(status_code=502, detail="ClipHub could not connect to Google's image-generation API. Check your internet connection.") from exc
    except (ValueError, KeyError, TypeError) as exc:
        raise HTTPException(status_code=502, detail="ClipHub received an unexpected image-generation response from Google. Restart ClipHub and try again.") from exc
    except httpx.HTTPError as exc:
        raise HTTPException(status_code=502, detail=f"Network error while contacting Gemini image generation ({type(exc).__name__}). Try again.") from exc

@app.post("/api/chat")
async def chat(req: ChatRequest):
    messages = req.messages[-20:]
    if not messages:
        raise HTTPException(status_code=400, detail="At least one message is required.")
    safe = [{"role": "system", "content": "You are ClipHub AI, a friendly assistant for video creators and students. Be helpful, clear, and honest."}]
    for message in messages:
        role = message.get("role")
        content = str(message.get("content", ""))[:12000]
        if role in ("user", "assistant") and content:
            safe.append({"role": role, "content": content})
    return await call_model(safe)


# ---------------------------------------------------------------------------
# AI Video Clipper
# - Gemini analyzes the uploaded video and suggests highlight timestamps.
# - FFmpeg performs real cuts, vertical/square/landscape formatting, and optional
#   burned-in captions. Generated files remain on this server for downloading.
# ---------------------------------------------------------------------------
CLIP_OUTPUT_ROOT = ROOT / "generated_clips"
CLIP_OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
MAX_CLIP_UPLOAD_MB = int(os.getenv("CLIPHUB_MAX_CLIP_UPLOAD_MB", "250"))
ALLOWED_VIDEO_SUFFIXES = {".mp4", ".mov", ".m4v", ".webm", ".avi", ".mkv", ".mpeg", ".mpg"}


def _clipper_ffmpeg() -> str:
    """Use imageio-ffmpeg's bundled ffmpeg so Windows users needn't install FFmpeg manually."""
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception as exc:
        raise HTTPException(
            status_code=503,
            detail="The video-processing engine is missing. Close ClipHub and run run_windows.bat again so its requirements can install."
        ) from exc



def _validated_youtube_url(raw_url: str) -> tuple[str, str]:
    """Accept only a single ordinary YouTube video URL (not arbitrary URLs/playlists)."""
    raw_url = (raw_url or "").strip()
    if not raw_url or len(raw_url) > 2048:
        raise HTTPException(status_code=400, detail="Paste a valid YouTube video link.")
    try:
        parsed = urlparse(raw_url)
    except Exception as exc:
        raise HTTPException(status_code=400, detail="That YouTube link could not be read. Paste the full video URL.") from exc

    host = (parsed.hostname or "").lower().rstrip(".")
    allowed_hosts = {"youtube.com", "www.youtube.com", "m.youtube.com", "music.youtube.com", "youtu.be", "www.youtu.be"}
    if parsed.scheme not in ("http", "https") or host not in allowed_hosts or parsed.username or parsed.password:
        raise HTTPException(status_code=400, detail="Use a normal youtube.com or youtu.be video link. Other websites are not supported here.")

    video_id = ""
    if host.endswith("youtu.be"):
        video_id = parsed.path.strip("/").split("/")[0]
    else:
        path_parts = [part for part in parsed.path.split("/") if part]
        if parsed.path.rstrip("/") == "/watch":
            video_id = parse_qs(parsed.query).get("v", [""])[0]
        elif len(path_parts) >= 2 and path_parts[0] in {"shorts", "live", "embed", "v"}:
            video_id = path_parts[1]

    if not re.fullmatch(r"[A-Za-z0-9_-]{11}", video_id or ""):
        raise HTTPException(status_code=400, detail="This does not look like a single YouTube video link. Use a watch, youtu.be, Shorts, live, or embed URL, not a playlist/channel link.")
    # Normalize to a canonical URL, stripping playlist and tracking parameters.
    return f"https://www.youtube.com/watch?v={video_id}", video_id


def _download_youtube_video(raw_url: str, working_dir: Path, ffmpeg: str, max_mb: int) -> tuple[Path, str, float]:
    """Download one authorized public YouTube video with robust format fallbacks."""
    normalized_url, _video_id = _validated_youtube_url(raw_url)
    try:
        import yt_dlp
    except Exception as exc:
        raise HTTPException(status_code=503, detail="YouTube link support is not installed yet. Close ClipHub and run run_windows.bat again to install/update yt-dlp.") from exc

    output_template = str(working_dir / "youtube_source.%(ext)s")
    # Some YouTube videos expose separate video/audio streams but no single
    # progressive MP4. Prefer a video stream up to 720p, then fall back to the
    # standard yt-dlp selector, and finally a combined format if available.
    format_selectors = [
        "bestvideo*[height<=720]+bestaudio/best[height<=720]/bestvideo*+bestaudio/best",
        "bestvideo*+bestaudio/best",
        "best",
    ]
    common_options = {
        "outtmpl": output_template,
        "noplaylist": True,
        "quiet": True,
        "no_warnings": True,
        "socket_timeout": 30,
        "retries": 2,
        "fragment_retries": 2,
        "max_filesize": max_mb * 1024 * 1024,
        "merge_output_format": "mp4",
        "ffmpeg_location": ffmpeg,
        "overwrites": False,
        "restrictfilenames": True,
    }
    # yt-dlp may need an external JavaScript runtime for current YouTube
    # extraction. Prefer Deno (recommended upstream), otherwise try Node.js.
    deno_path = shutil.which("deno")
    node_path = shutil.which("node")
    if deno_path:
        common_options["js_runtimes"] = {"deno": {"path": deno_path}}
    elif node_path:
        common_options["js_runtimes"] = {"node": {"path": node_path}}

    title = "YouTube video"
    duration = 0.0
    last_error = None
    succeeded = False

    for selector_index, format_selector in enumerate(format_selectors):
        options = dict(common_options)
        options["format"] = format_selector
        try:
            with yt_dlp.YoutubeDL(options) as downloader:
                info = downloader.extract_info(normalized_url, download=False)
                if not isinstance(info, dict) or info.get("_type") == "playlist":
                    raise HTTPException(status_code=400, detail="Please paste a link to one YouTube video, not a playlist.")
                duration = _sec(info.get("duration"), 0)
                if duration and duration < 5:
                    raise HTTPException(status_code=400, detail="This YouTube video is shorter than 5 seconds. Choose a longer video.")
                if duration > 3 * 3600:
                    raise HTTPException(status_code=400, detail="ClipHub supports source videos up to 3 hours long.")
                title = str(info.get("title") or "YouTube video").strip()[:180]
                downloader.process_ie_result(info, download=True)
            succeeded = True
            break
        except HTTPException:
            raise
        except Exception as exc:
            last_error = exc
            message = " ".join(str(exc).split())
            low = message.lower()
            # Retry only format-selection errors. Repeatedly retrying an auth,
            # network, geo, or JavaScript challenge failure cannot fix it.
            can_retry_format = "requested format is not available" in low and selector_index < len(format_selectors) - 1
            if can_retry_format:
                for partial in working_dir.glob("youtube_source.*"):
                    try:
                        if partial.is_file():
                            partial.unlink()
                    except OSError:
                        pass
                continue
            break

    if not succeeded:
        message = " ".join(str(last_error or "Unknown YouTube import error").split())[:360]
        low = message.lower()
        if "requested format is not available" in low:
            detail = (
                "ClipHub tried multiple YouTube format selectors but yt-dlp could not find a compatible downloadable audio/video format. "
                "Close ClipHub and run run_windows.bat again so yt-dlp can update. If it still fails, install Deno 2.3+ from https://deno.com/ "
                "and restart ClipHub; YouTube may not be exposing downloadable formats for this video. Details: " + message
            )
        elif any(token in low for token in ("private video", "members-only", "sign in", "login required", "age-restricted")):
            detail = "ClipHub could not access this video because it may be private, restricted, age-gated, or require sign-in. Try a public video you are authorized to edit."
        elif any(token in low for token in ("javascript", "js challenge", "deno", "ejs")):
            detail = "YouTube requires a supported JavaScript runtime for this link. Install Deno 2.3 or newer, then restart ClipHub. Details: " + message
        elif "max-filesize" in low or "file is larger than" in low or ("filesize" in low and "exceed" in low):
            detail = f"This YouTube video exceeds ClipHub's {max_mb} MB source limit. Choose a shorter/lower-resolution video or upload a smaller authorized file."
        else:
            detail = "ClipHub could not import this YouTube video. It may be unavailable, blocked by YouTube, or require an updated yt-dlp/JavaScript runtime. Try a public video you are authorized to edit. Details: " + message
        raise HTTPException(status_code=502, detail=detail) from last_error

    candidates = [p for p in working_dir.glob("youtube_source.*") if p.is_file() and not p.name.endswith((".part", ".ytdl", ".temp"))]
    candidates = [p for p in candidates if p.suffix.lower() in ALLOWED_VIDEO_SUFFIXES]
    if not candidates:
        raise HTTPException(status_code=502, detail="YouTube reported that the video was available, but ClipHub could not find the downloaded video file. Try another link.")
    source_path = next((p for p in candidates if p.suffix.lower() == ".mp4"), candidates[0])
    size = source_path.stat().st_size
    if size <= 0:
        raise HTTPException(status_code=502, detail="The downloaded YouTube video was empty. Try another link.")
    if size > max_mb * 1024 * 1024:
        source_path.unlink(missing_ok=True)
        raise HTTPException(status_code=413, detail=f"This YouTube video exceeds ClipHub's {max_mb} MB source limit. Choose a shorter/lower-resolution video.")
    if not duration:
        duration = _video_duration_seconds(ffmpeg, source_path)
    return source_path, title, duration


def _video_duration_seconds(ffmpeg: str, filename: Path) -> float:
    # `ffmpeg -i file` prints stream metadata before exiting; we only parse metadata,
    # rather than decoding the whole source video just to discover its duration.
    try:
        result = subprocess.run(
            [ffmpeg, "-hide_banner", "-i", str(filename)],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=35
        )
    except subprocess.TimeoutExpired as exc:
        raise HTTPException(status_code=400, detail="ClipHub could not inspect this video quickly enough. Try a smaller or standard MP4 file.") from exc
    text = (result.stderr or "") + "\n" + (result.stdout or "")
    match = re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", text)
    if not match:
        raise HTTPException(status_code=400, detail="ClipHub could not read the video's duration. Try exporting it as MP4 (H.264 video with AAC audio) and upload it again.")
    hours, minutes, seconds = match.groups()
    duration = int(hours) * 3600 + int(minutes) * 60 + float(seconds)
    if duration < 5:
        raise HTTPException(status_code=400, detail="Please upload a video that is at least 5 seconds long.")
    if duration > 3 * 3600:
        raise HTTPException(status_code=400, detail="This starter version supports source videos up to 3 hours long.")
    return duration


def _json_from_model(text: str) -> dict:
    cleaned = (text or "").strip()
    cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned, flags=re.I)
    cleaned = re.sub(r"\s*```$", "", cleaned)
    start, end = cleaned.find("{"), cleaned.rfind("}")
    if start < 0 or end <= start:
        raise ValueError("Model did not return a JSON object")
    result = json.loads(cleaned[start:end + 1])
    if not isinstance(result, dict):
        raise ValueError("Model result is not an object")
    return result


def _clipper_models() -> list[str]:
    primary = os.getenv("AI_VIDEO_MODEL", "").strip()
    fallbacks_raw = os.getenv("AI_VIDEO_FALLBACK_MODELS", "").strip()
    if not primary:
        return _configured_models()
    fallbacks = [item.strip() for item in fallbacks_raw.split(",") if item.strip()]
    if not fallbacks:
        fallbacks = _configured_models()
    return list(dict.fromkeys([primary] + fallbacks))


def _analyze_video_with_gemini(video_path: Path, prompt: str, api_key: str) -> tuple[dict, str]:
    """Upload video to Gemini, wait for processing, ask for highlight JSON, then delete provider copy."""
    try:
        from google import genai
    except Exception as exc:
        raise HTTPException(status_code=503, detail="The Gemini video-analysis package is missing. Restart ClipHub using run_windows.bat to install requirements.") from exc

    client = genai.Client(api_key=api_key)
    remote_file = None
    try:
        try:
            remote_file = client.files.upload(file=str(video_path))
        except Exception as exc:
            msg = str(exc).replace(api_key, "[hidden API key]")[:260]
            raise HTTPException(status_code=502, detail="Google could not accept this video upload. Check Gemini API access, file type, upload size, and quota. Details: " + msg) from exc

        # Gemini processes video asynchronously before it can be used as a model input.
        state = ""
        for _ in range(90):
            status_obj = getattr(remote_file, "state", None)
            state = str(getattr(status_obj, "name", status_obj or "")).upper()
            if state.endswith("ACTIVE") or state == "ACTIVE":
                break
            if "FAILED" in state:
                raise HTTPException(status_code=502, detail="Google could not process this video. Try a smaller MP4 video or check your Gemini API limits.")
            time.sleep(2)
            remote_file = client.files.get(name=remote_file.name)
        else:
            raise HTTPException(status_code=504, detail="Google is taking too long to process this video. Try again with a shorter or smaller video.")

        last_error = None
        models = _clipper_models()
        for model in models:
            try:
                response = client.models.generate_content(model=model, contents=[remote_file, prompt])
                text_value = getattr(response, "text", None)
                parsed = _json_from_model(text_value or "")
                return parsed, model
            except HTTPException:
                raise
            except Exception as exc:
                message = str(exc).replace(api_key, "[hidden API key]")
                last_error = message[:320]
                lower = message.lower()
                retryable = any(token in lower for token in (
                    "429", "500", "502", "503", "504", "resource_exhausted", "unavailable",
                    "high demand", "overload", "not found", "unsupported", "video", "media", "json", "return a json"
                ))
                if not retryable:
                    break

        detail = "Gemini could not analyze this video with the configured models."
        if last_error:
            detail += " Check the AI model, Gemini quota, and API access. Google details: " + last_error
        raise HTTPException(status_code=502, detail=detail)
    finally:
        if remote_file is not None:
            try:
                client.files.delete(name=remote_file.name)
            except Exception:
                # Best effort: keep processing results usable even if provider-side cleanup fails.
                pass
        try:
            client.close()
        except Exception:
            pass


def _sec(value, default=0.0) -> float:
    try:
        if isinstance(value, str):
            value = value.strip().replace(",", ".")
        result = float(value)
        if result != result or result in (float("inf"), float("-inf")):
            return default
        return result
    except (TypeError, ValueError):
        return default


def _safe_caption_text(text: str) -> str:
    text = str(text or "").replace("\r", " ").replace("\n", " ").strip()
    # ASS override sequences must not be accepted from model-generated caption text.
    text = text.replace("{", "(").replace("}", ")")
    return text[:180]


def _ass_timestamp(seconds: float) -> str:
    seconds = max(0.0, seconds)
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = seconds % 60
    return f"{hours}:{minutes:02d}:{secs:05.2f}"


def _write_clip_captions(job_dir: Path, clip_index: int, captions: list, clip_duration: float, target_size: tuple[int, int]) -> tuple[Path | None, Path | None, int]:
    width, height = target_size
    srt_path = job_dir / f"clip_{clip_index:02d}.srt"
    ass_path = job_dir / f"clip_{clip_index:02d}.ass"
    valid = []
    for cue in captions if isinstance(captions, list) else []:
        if not isinstance(cue, dict):
            continue
        start = _sec(cue.get("start_seconds"), -1)
        end = _sec(cue.get("end_seconds"), -1)
        caption = _safe_caption_text(cue.get("text", ""))
        if not caption or start < 0 or end <= start or start >= clip_duration:
            continue
        end = min(end, clip_duration)
        if end - start < 0.18:
            continue
        valid.append((start, end, caption))
    valid.sort(key=lambda item: item[0])
    if not valid:
        return None, None, 0

    def srt_time(sec: float) -> str:
        millis = int(round(max(0.0, sec) * 1000))
        hours, millis = divmod(millis, 3_600_000)
        minutes, millis = divmod(millis, 60_000)
        seconds, millis = divmod(millis, 1000)
        return f"{hours:02d}:{minutes:02d}:{seconds:02d},{millis:03d}"

    with srt_path.open("w", encoding="utf-8-sig", newline="\n") as out:
        for index, (start, end, caption) in enumerate(valid, 1):
            out.write(f"{index}\n{srt_time(start)} --> {srt_time(end)}\n{caption}\n\n")

    ass_header = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {width}
PlayResY: {height}
WrapStyle: 2
ScaledBorderAndShadow: yes
[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,Arial,{max(26, round(height * 0.032))},&H00FFFFFF,&H0000FFFF,&H00000000,&H80000000,-1,0,1,4,2,2,60,60,{max(80, round(height * 0.07))},1
[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    with ass_path.open("w", encoding="utf-8", newline="\n") as out:
        out.write(ass_header)
        for start, end, caption in valid:
            # Split long captions into short readable lines for vertical video.
            text = caption.replace("\\", "\\\\")
            if len(text) > 44 and " " in text:
                words = text.split()
                lines, line = [], ""
                for word in words:
                    if line and len(line) + len(word) + 1 > 30:
                        lines.append(line)
                        line = word
                    else:
                        line = (line + " " + word).strip()
                if line:
                    lines.append(line)
                text = r"\N".join(lines[:3])
            out.write(f"Dialogue: 0,{_ass_timestamp(start)},{_ass_timestamp(end)},Default,,0,0,0,,{text}\n")
    return srt_path, ass_path, len(valid)


def _render_one_clip(ffmpeg: str, source_path: Path, output_path: Path, start: float, end: float,
                     aspect_ratio: str, ass_filename: str | None, working_dir: Path) -> tuple[bool, str]:
    dimensions = {"9:16": (1080, 1920), "1:1": (1080, 1080), "16:9": (1920, 1080)}
    width, height = dimensions.get(aspect_ratio, (1080, 1920))
    # Crop to the target ratio, then scale. Users may revise framing in their main editor.
    video_filter = f"scale={width}:{height}:force_original_aspect_ratio=increase,crop={width}:{height},setsar=1,fps=30"
    if ass_filename:
        video_filter += f",subtitles={ass_filename}"

    def run(use_filter: str):
        command = [
            ffmpeg, "-hide_banner", "-loglevel", "error", "-y", "-ss", f"{start:.3f}",
            "-i", str(source_path), "-t", f"{(end - start):.3f}",
            "-map", "0:v:0", "-map", "0:a?", "-vf", use_filter,
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "23", "-pix_fmt", "yuv420p",
            "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", str(output_path)
        ]
        return subprocess.run(command, cwd=str(working_dir), stdout=subprocess.PIPE,
                              stderr=subprocess.PIPE, text=True, timeout=15 * 60)

    try:
        result = run(video_filter)
    except subprocess.TimeoutExpired as exc:
        raise HTTPException(status_code=504, detail="FFmpeg took too long to render a clip. Try fewer or shorter clips.") from exc
    if result.returncode == 0 and output_path.exists() and output_path.stat().st_size > 0:
        return (ass_filename is not None), ""
    # Some FFmpeg builds ship without libass. If subtitles were requested, retry the video
    # render without burn-in; the generated .srt can still be downloaded separately.
    if ass_filename:
        try:
            result = run(video_filter.rsplit(",subtitles=", 1)[0])
        except subprocess.TimeoutExpired as exc:
            raise HTTPException(status_code=504, detail="FFmpeg took too long to render this clip. Try fewer or shorter clips.") from exc
        if result.returncode == 0 and output_path.exists() and output_path.stat().st_size > 0:
            return False, "Burned-in captions aren't available in this FFmpeg build; download the SRT subtitle file separately."
    detail = (result.stderr or "FFmpeg could not export this clip.").strip().splitlines()
    raise HTTPException(status_code=500, detail="Could not export the video clip. " + " ".join(detail[-3:])[:360])


@app.post("/api/clipper/clip")
def create_ai_clips(
    video: UploadFile | None = File(None),
    youtube_url: str = Form(""),
    youtube_authorized: bool = Form(False),
    clip_count: int = Form(3),
    clip_seconds: int = Form(30),
    aspect_ratio: str = Form("9:16"),
    focus: str = Form(""),
    captions: bool = Form(True),
):
    """Create highlight clips from an uploaded file or a permitted YouTube source."""
    api_key = os.getenv("AI_API_KEY", "").strip()
    if not api_key:
        raise HTTPException(status_code=503, detail="Google AI Studio API key is not configured. Restart ClipHub and enter your key in the launcher.")
    youtube_url = (youtube_url or "").strip()
    has_upload = video is not None and bool(video.filename)
    has_youtube = bool(youtube_url)
    if has_upload == has_youtube:
        raise HTTPException(status_code=400, detail="Choose either a video file or a YouTube link, not both.")
    if has_upload and Path(video.filename).suffix.lower() not in ALLOWED_VIDEO_SUFFIXES:
        raise HTTPException(status_code=400, detail="Upload a supported video file: MP4, MOV, M4V, WebM, AVI, MKV, MPEG or MPG.")
    if has_youtube and not youtube_authorized:
        raise HTTPException(status_code=400, detail="Confirm that you own this video or have the rights and authorization to download and edit it.")
    if has_youtube:
        _validated_youtube_url(youtube_url)
    if not 1 <= clip_count <= 6:
        raise HTTPException(status_code=400, detail="Choose between 1 and 6 clips per video.")
    if clip_seconds not in (15, 20, 30, 45, 60):
        raise HTTPException(status_code=400, detail="Choose a clip length of 15, 20, 30, 45 or 60 seconds.")
    if aspect_ratio not in ("9:16", "1:1", "16:9"):
        raise HTTPException(status_code=400, detail="Choose 9:16, 1:1 or 16:9 output format.")
    focus = (focus or "general engaging highlights").strip()[:500]
    job_id = uuid.uuid4().hex[:16]
    job_output_dir = CLIP_OUTPUT_ROOT / job_id
    job_output_dir.mkdir(parents=True, exist_ok=False)
    working_dir = Path(tempfile.mkdtemp(prefix=f"cliphub-{job_id}-"))
    source_path = working_dir / "source.mp4"
    source_title = (Path(video.filename).name[:180] if has_upload else "YouTube video")

    try:
        ffmpeg = _clipper_ffmpeg()
        if has_youtube:
            source_path, source_title, video_duration = _download_youtube_video(
                youtube_url, working_dir, ffmpeg, MAX_CLIP_UPLOAD_MB
            )
        else:
            suffix = Path(video.filename).suffix.lower()
            source_path = working_dir / ("source" + suffix)
            total_bytes = 0
            # Stream the incoming upload to disk and enforce a size cap while reading.
            video.file.seek(0)
            with source_path.open("wb") as output:
                while True:
                    chunk = video.file.read(1024 * 1024)
                    if not chunk:
                        break
                    total_bytes += len(chunk)
                    if total_bytes > MAX_CLIP_UPLOAD_MB * 1024 * 1024:
                        raise HTTPException(status_code=413, detail=f"This starter supports videos up to {MAX_CLIP_UPLOAD_MB} MB. Compress the source video or choose a shorter file.")
                    output.write(chunk)
            if total_bytes == 0:
                raise HTTPException(status_code=400, detail="The uploaded video is empty. Choose a video file and try again.")
            video_duration = _video_duration_seconds(ffmpeg, source_path)
        if video_duration < min(clip_seconds, 10):
            raise HTTPException(status_code=400, detail=f"This video is only {video_duration:.1f} seconds long. Choose a shorter target clip length or upload a longer video.")
        requested_seconds = min(float(clip_seconds), max(5.0, video_duration * 0.9))
        actual_count = min(clip_count, max(1, int(video_duration // max(5, requested_seconds * 0.55))))
        if video_duration <= requested_seconds * 1.2:
            actual_count = 1

        captions_instruction = (
            "For every clip, include 4-10 short caption cues timed relative to that clip's start (not the source video's start), using start_seconds, end_seconds and text. Aim for concise spoken phrases. These are AI-estimated timings and may need review."
            if captions else "Set captions to an empty array for every clip."
        )
        prompt = f"""You are the highlight editor for a short-form video product. Analyze the attached video including audio and visuals. Find up to {actual_count} distinct, compelling highlights for {focus}. Output clips targeted around {requested_seconds:.0f} seconds long (allowed range: 8 seconds to {min(video_duration, requested_seconds * 1.4):.1f} seconds). Source duration is {video_duration:.2f} seconds. Output aspect ratio will be {aspect_ratio}.
Prioritize a strong opening hook, a complete thought or event payoff, emotional/novel moments, useful information, or clear visual action. Avoid introductions, dead air, mid-sentence starts, and repeated moments. Do not invent anything that isn't in the video. Use different, non-overlapping moments whenever possible. All clip start_seconds and end_seconds are absolute times in the original source video, in seconds. Keep times >= 0 and <= {video_duration:.2f}. {captions_instruction}
Return ONLY a valid JSON object (no markdown, no explanation) in this exact shape:
{{"clips":[{{"title":"short title","start_seconds":12.5,"end_seconds":40.0,"hook":"brief reason this moment works","captions":[{{"start_seconds":0.0,"end_seconds":2.2,"text":"caption phrase"}}]}}]}}
Return no more than {actual_count} clips. Do not return a clip shorter than 5 seconds. Title 2-8 words. Captions must be short (ideally 3-8 words each), sequential, non-overlapping, and fit inside the selected clip duration. If speech is unclear or absent, caption visually useful narration sparingly."""

        analysis, model_used = _analyze_video_with_gemini(source_path, prompt, api_key)
        raw_clips = analysis.get("clips", [])
        if not isinstance(raw_clips, list) or not raw_clips:
            raise HTTPException(status_code=502, detail="Gemini analyzed the video but did not return valid highlight timestamps. Try another video or reduce the number of clips.")

        dimensions = {"9:16": (1080, 1920), "1:1": (1080, 1080), "16:9": (1920, 1080)}
        width, height = dimensions[aspect_ratio]
        results = []
        warnings = []
        for clip_obj in raw_clips[:actual_count]:
            if not isinstance(clip_obj, dict):
                continue
            raw_start = _sec(clip_obj.get("start_seconds"), -1)
            raw_end = _sec(clip_obj.get("end_seconds"), -1)
            if raw_start < 0 or raw_end <= raw_start:
                continue
            start = max(0.0, raw_start)
            end = min(video_duration, raw_end)
            if end <= start:
                continue
            # Constrain lengths if the model accidentally returned a much longer segment.
            max_len = min(video_duration, requested_seconds * 1.4)
            min_len = min(5.0, video_duration)
            if end - start > max_len:
                end = min(video_duration, start + max_len)
            if end - start < min_len:
                continue
            clip_duration = end - start
            idx = len(results) + 1
            raw_title = str(clip_obj.get("title", f"Highlight {idx}")).strip()
            title = re.sub(r"[^\w\- ]+", "", raw_title, flags=re.UNICODE).strip()[:70] or f"Highlight {idx}"
            hook = str(clip_obj.get("hook", "AI-selected video highlight")).strip()[:240]
            output_name = f"clip_{idx:02d}.mp4"
            output_path = job_output_dir / output_name
            srt_path = None
            ass_path = None
            caption_count = 0
            if captions:
                srt_path, ass_path, caption_count = _write_clip_captions(
                    working_dir, idx, clip_obj.get("captions", []), clip_duration, (width, height)
                )
            ass_filename = ass_path.name if ass_path else None
            burned, warning = _render_one_clip(
                ffmpeg, source_path, output_path, start, end, aspect_ratio, ass_filename, working_dir
            )
            if warning and warning not in warnings:
                warnings.append(warning)
            result_item = {
                "title": title,
                "hook": hook,
                "start_seconds": round(start, 2),
                "end_seconds": round(end, 2),
                "duration_seconds": round(clip_duration, 2),
                "video_url": f"/api/clipper/files/{job_id}/{output_name}",
                "download_name": output_name,
                "captions_burned_in": bool(burned and caption_count),
                "caption_count": caption_count,
            }
            if srt_path and srt_path.exists():
                srt_name = srt_path.name
                shutil.copy2(srt_path, job_output_dir / srt_name)
                result_item["subtitle_url"] = f"/api/clipper/files/{job_id}/{srt_name}"
                result_item["subtitle_name"] = srt_name
            results.append(result_item)

        if not results:
            raise HTTPException(status_code=502, detail="Gemini returned highlight timestamps that could not be turned into clips. Try again or choose a different target length.")
        return {
            "job_id": job_id,
            "source_duration_seconds": round(video_duration, 2),
            "source_title": source_title,
            "source_type": "youtube" if has_youtube else "upload",
            "clips": results,
            "model": model_used,
            "aspect_ratio": aspect_ratio,
            "warnings": warnings,
            "note": "The source video is processed on this ClipHub server. Gemini is used for highlight analysis; FFmpeg creates the exported clips. Review timestamps and AI-estimated captions before publishing."
        }
    except HTTPException:
        shutil.rmtree(job_output_dir, ignore_errors=True)
        raise
    except Exception as exc:
        shutil.rmtree(job_output_dir, ignore_errors=True)
        safe = str(exc).replace(api_key, "[hidden API key]")[:280]
        raise HTTPException(status_code=500, detail="ClipHub's video clipper failed. Check the terminal for details. " + safe) from exc
    finally:
        if video is not None:
            try:
                video.file.close()
            except Exception:
                pass
        shutil.rmtree(working_dir, ignore_errors=True)


@app.get("/api/clipper/files/{job_id}/{filename}")
def download_ai_clip(job_id: str, filename: str):
    if not re.fullmatch(r"[a-f0-9]{16}", job_id) or Path(filename).name != filename or filename.startswith("."):
        raise HTTPException(status_code=404, detail="Clip file not found.")
    target_dir = CLIP_OUTPUT_ROOT / job_id
    target = target_dir / filename
    if not target.is_file() or target.resolve().parent != target_dir.resolve():
        raise HTTPException(status_code=404, detail="Clip file not found. It may have been deleted from the server.")
    media_type = "video/mp4" if target.suffix.lower() == ".mp4" else "application/x-subrip"
    return FileResponse(target, media_type=media_type, filename=filename)
