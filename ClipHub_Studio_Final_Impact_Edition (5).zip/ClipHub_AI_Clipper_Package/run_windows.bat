@echo off
setlocal
cd /d "%~dp0"
title ClipHub Studio - Final Impact Edition

echo ========================================
echo       ClipHub Studio - Final Impact Edition
echo ========================================
echo.
where py >nul 2>nul
if errorlevel 1 (
  echo Python was not found.
  echo Install Python 3.10 or newer from https://www.python.org/downloads/
  echo IMPORTANT: tick "Add Python to PATH" during installation.
  pause
  exit /b 1
)

if not exist .venv\Scripts\python.exe (
  echo Step 1 of 3: Preparing Python environment...
  py -3 -m venv .venv
  if errorlevel 1 goto failed
)
echo Step 2 of 3: Installing required packages (first time can take a few minutes)...
.venv\Scripts\python.exe -m pip install --upgrade pip
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto failed
.venv\Scripts\python.exe -m pip install --upgrade "yt-dlp[default]"
if errorlevel 1 (
  echo WARNING: yt-dlp could not be updated. ClipHub will try the installed version.
  echo If YouTube links still fail, check your internet connection and run this launcher again.
)

echo.
echo Step 3 of 3: Connect Google AI Studio.
echo Paste your Google AI Studio API key below, then press Enter.
echo Keep this window private. Do not send anyone your key or a screenshot showing it.
set /p AI_API_KEY="Google AI Studio API key: "
if "%AI_API_KEY%"=="" (
  echo No API key entered. Double-click this file again and try once more.
  pause
  exit /b 1
)
set "AI_MODEL=gemini-3.5-flash-lite"
set "AI_FALLBACK_MODELS=gemini-3.1-flash-lite,gemini-3.6-flash"
set "AI_VIDEO_MODEL=gemini-3.8-flash"
set "AI_VIDEO_FALLBACK_MODELS=gemini-3.6-flash,gemini-3.5-flash-lite,gemini-3.1-flash-lite"
echo.
echo Starting ClipHub Studio Final Impact Edition. Primary model: %AI_MODEL%
echo If the primary text model is overloaded, ClipHub tries text fallback models.
echo Image Creator uses Google's separate image models with their own fallbacks.
echo AI Video Clipper accepts local video uploads or authorized YouTube video links; Gemini finds highlights and FFmpeg renders MP4 clips.
where deno >nul 2>nul
if errorlevel 1 (
  where node >nul 2>nul
  if errorlevel 1 (
    echo NOTE: Deno 2.3+ is recommended for YouTube link imports. Install it from https://deno.com if link import fails.
  ) else (
    echo JavaScript runtime found: Node. YouTube import will try using it.
  )
) else (
  echo JavaScript runtime found: Deno.
)
echo Keep this black window open while using it.
echo Open http://127.0.0.1:8000 in your browser when startup completes.
echo The site uses the black, red and white Impact Edition design with click/tap impact frames.
echo Diagnostic status: http://127.0.0.1:8000/api/health
echo.
.venv\Scripts\python.exe -m uvicorn app:app --host 127.0.0.1 --port 8000
pause
exit /b 0

:failed
echo.
echo Setup failed. Read the error above. If packages failed to install, check your internet connection.
pause
exit /b 1
